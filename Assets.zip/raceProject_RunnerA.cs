using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class raceProject_RunnerA : MonoBehaviour
{

    public int runnerPosition;
    //public int runnerBPosition;

    // private int runnerA = 0;
    // private int runnerB = 0;


    public float speed = 1f;
    public bool isGrass;
    public float turnDuration = 1;

    public List<GameObject> course = new List<GameObject>();

    private void Awake()
    {
        /*foreach (GameObject gameObj in course)
        {
            bool isGrass = gameObj.name == "Grass";
            Debug.Log($"This Tile is grass: {isGrass}");

            if (isGrass == true)
            {
                float grassMoveForward = 0.25f;
                transform.position += transform.forward * grassMoveForward;
            }
            else
            {
                float mudMoveForward = 0.125f;
                transform.position += transform.forward * mudMoveForward;
            }
        }*/
    }


    private void Update()
    {
        
    }


    private void Start()
    {
        StartCoroutine(GameLoop());

    }

    private IEnumerator GameLoop()
    {
        while(true)
        {
            isGrass = course[runnerPosition].name == "Grass";
            if (isGrass == true)
            {
                var randomNum = Random.Range(0, 4);
                if (randomNum == 0)
                {
                    transform.position += transform.forward * 500;
                    runnerPosition += 1;
                }

            }
            else
            {
                var randomNum = Random.Range(0, 8);
                if (randomNum == 0)
                {
                    transform.position += transform.forward * 500;
                    runnerPosition += 1;

                }
            }
            yield return new WaitForSeconds(1);
        }
    }

    

    private void OnTriggerEnter(Collider other)
    {
        Debug.Log("Object has reached the finish line!");
    }

   
 
}


