using UnityEngine;

public class StopOnCollision : MonoBehaviour
{
    private Vector3 velocity;

    private void Start()
    {
        velocity = Vector3.zero;
    }

    private void Update()
    {
        transform.position += velocity * Time.deltaTime;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Box Collider"))
        {
            velocity = Vector3.zero;
        }
    }
}
